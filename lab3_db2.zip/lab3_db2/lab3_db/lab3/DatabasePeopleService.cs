using Lab1.Database;
using Microsoft.EntityFrameworkCore;


namespace CdvAzure.Functions
{

    public class DatabasePeopleService : PeopleService
    {
        private readonly PeopleDb db;

    

        public DatabasePeopleService(PeopleDb db)
        {
            this.db = db;
        }
    

        public IEnumerable<Person> GetPeople()
        {
            var peopleList = db.People.Select(s=> new Person{
                FirstName = s.FirstName,
                Id = s.Id,
                LastName = s.LastName
            });

            return peopleList;

        }

    }
}

